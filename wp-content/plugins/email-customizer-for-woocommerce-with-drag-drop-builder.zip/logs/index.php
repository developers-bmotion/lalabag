<?php

// Silence is golden ;)

?>