<?php
if ( !class_exists('WooMail_Puc_v4_Factory', false) ):

	class WooMail_Puc_v4_Factory extends WooMail_Puc_v4p4_Factory { }

endif;