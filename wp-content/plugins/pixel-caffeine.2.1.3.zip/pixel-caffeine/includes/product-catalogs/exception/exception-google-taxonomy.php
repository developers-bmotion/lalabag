<?php

namespace PixelCaffeine\ProductCatalog\Exception;

use PixelCaffeine\Admin\Exception\AEPCException;

/**
 * Class for Feed specific exceptions
 */
class GoogleTaxonomyException extends \Exception {}
