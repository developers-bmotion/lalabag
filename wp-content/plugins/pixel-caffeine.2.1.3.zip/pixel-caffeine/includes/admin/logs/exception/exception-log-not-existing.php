<?php

namespace PixelCaffeine\Logs\Exception;


class LogNotExistingException extends \Exception {

}
