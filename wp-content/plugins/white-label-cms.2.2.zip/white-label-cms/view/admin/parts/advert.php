<div class="wlcms-advert-wrapper">
	<a href="http://wplinks.io/workshop-wlcms" target="_blank">
		<picture>
			<source srcset="<?php echo WLCMS_ASSETS_URL ?>images/Better-Clients-Banner-white-label-cms-m.jpg" media="(max-width: 480px)">
			<img srcset="<?php echo WLCMS_ASSETS_URL ?>images/Better-Clients-Banner.jpg" alt="3 secrets to Better Client, Better Projects & Better Fees">
		</picture>
	</a>
</div>