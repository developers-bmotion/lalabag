<?php

return array(
	'subscriptions' => array(
		'home' => array(
			'type'         => 'custom_tab',
			'action'       => 'yith_ywsbs_subscriptions_tab',
			'hide_sidebar' => true,
		),
	),
);
