<?php

return array(
	'pending_orders' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_ywrac_pending_orders',
		),
	),
);
