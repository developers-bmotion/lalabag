<dl>
  <dt><?php _e( 'Total scheduled exports', 'woocommerce-exporter' ); ?></dt>
  <dd><?php echo $exports; ?></dd>
  <dt><?php _e( 'Last scheduled export', 'woocommerce-exporter' ); ?></dt>
  <dd><?php echo $last_export; ?></dd>
</dl>